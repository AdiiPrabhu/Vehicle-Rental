package com.main.enroute.ownerclasses.myVehicle;

import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.ViewPager;

import com.main.enroute.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.main.enroute.ownerclasses.ownerDataFields.motorDetails;
import com.main.enroute.ownerclasses.ownerViewPageAdapter.FragmentAddressOwner;
import com.main.enroute.ownerclasses.ownerViewPageAdapter.FragmentMotorOwner;
import com.main.enroute.ownerclasses.ownerViewPageAdapter.FragmentRentOwner;
import com.main.enroute.ownerclasses.ownerViewPageAdapter.ViewPagerAdapterOwner;
import com.squareup.picasso.Picasso;

public class owner_after_clicking_hisvehicle extends AppCompatActivity {
    DatabaseReference ref,ref1,ref2;
    private FirebaseAuth mAuth;
    FirebaseDatabase database;
    ImageView houseImage;
    String motoraddress1, motorno1,s1;
    String bike1, bikeno1;
    String due1, city1;
    String area1, seater1, rent1, deposit1, document1, petrol1, renter1, state1;
    String str,date,time;
    motorDetails fd;
    private TabLayout tablayout;
    private AppBarLayout appBarLayout;
    private ViewPager viewPager;
    String strouid;
    String key="";
    String imageUrl="";
    Button deleteVehiclebyOwner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner_after_clicking_hisvehicle);
        deleteVehiclebyOwner = findViewById(R.id.btnDeleteVehicle);
        tablayout = (TabLayout) findViewById(R.id.tablayout_id);
        appBarLayout = (AppBarLayout) findViewById(R.id.appbarid);
        viewPager = (ViewPager) findViewById(R.id.viewpager_id);
        // ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());

        //Adding Fragments

        //adapter Setup

        Bundle mBundle = getIntent().getExtras();

        if (mBundle != null) {

            str = mBundle.getString("Image");
            strouid = str;

            FragmentManager manager = getSupportFragmentManager();
            final ViewPagerAdapterOwner adapter=new ViewPagerAdapterOwner(manager);
            adapter.AddFragment(new FragmentMotorOwner(), "Motor");
            adapter.AddFragment(new FragmentRentOwner(), "Rent");
            adapter.AddFragment(new FragmentAddressOwner(), "Address");

            viewPager.setAdapter(adapter);
            tablayout.setupWithViewPager(viewPager);
            houseImage = (ImageView) findViewById(R.id.motorimage);


            // houseImage.setImageResource(mBundle.getInt("Description"));

//            ref.addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//
//                    fd=dataSnapshot.getValue(motorDetails.class);
//                    bike1=dataSnapshot.child("bikename").getValue(String.class);
//                    bikeno1=(fd.getBikeno())+"";
//                    Log.i("bikeno1",bikeno1);
//                    seater1=(fd.getSEATER())+"";
//                    rent1=(fd.getRent())+"";
//                    deposit1=(fd.getDeposit())+"";
//                    if(dataSnapshot.child("document").getValue().toString().equals("true"))
//                    {
//                        document1="Document";
//                    }
//                    else
//                    {
//                        document1="Not Document";
//                    }
//                    petrol1=dataSnapshot.child("petrol").getValue(Long.class).toString();
//
//                    motoraddress1=dataSnapshot.child("motoraddress").getValue(String.class);
//                    if(dataSnapshot.child("due").getValue().toString().equals("true"))
//                    {
//                       due1="available";
//                    }
//                    else
//                    {
//                      due1="Not available";
//                    }
//                    area1=dataSnapshot.child("area").getValue(String.class);
//                    renter1=dataSnapshot.child("renter").getValue(String.class);
//                    city1=dataSnapshot.child("city").getValue(String.class);
//
//                    ((TextView)findViewById(R.id.bikename)).setText(bike1);
//                    ((TextView)findViewById(R.id.seater)).setText(seater1);
////                    ((TextView)findViewById(R.id.rent)).setText(rent1);
////                    ((TextView)findViewById(R.id.deposit)).setText(deposit1);
////                   ((TextView)findViewById(R.id.document)).setText(document1);
////                    ((TextView)findViewById(R.id.petrol)).setText(petrol1);
////                    ((TextView)findViewById(R.id.motoraddress)).setText(motoraddress1);
////                    ((TextView)findViewById(R.id.due)).setText(due1);
////                    ((TextView)findViewById(R.id.area)).setText(area1);
////                    ((TextView)findViewById(R.id.renter)).setText(renter1);
////                    ((TextView)findViewById(R.id.city)).setText(city1);
////                    ((TextView)findViewById(R.id.motorno)).setText(motorno1);
//                }
//
//                @Override
//                public void onCancelled(@NonNull DatabaseError databaseError) {
//
//                }
//            });
//        }

//            final Button request = (Button) findViewById(R.id.request);
//            eText=(EditText) findViewById(R.id.editText1);
//            txttime=(EditText) findViewById(R.id.time);
//
//            eText.setInputType(InputType.TYPE_NULL);
//            eText.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    final Calendar cldr = Calendar.getInstance();
//                    int day = cldr.get(Calendar.DAY_OF_MONTH);
//                    int month = cldr.get(Calendar.MONTH);
//                    int year = cldr.get(Calendar.YEAR);
//                    // date picker dialog
//                    picker = new DatePickerDialog(owner_after_clicking_hisvehicle.this,
//                            new DatePickerDialog.OnDateSetListener() {
//                                @Override
//                                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
//                                    eText.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
//                                    date=(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
//
//                                }
//                            }, year, month, day);
//                    picker.show();
//                }
//            });


//            request.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    mAuth = FirebaseAuth.getInstance();
//                    database = FirebaseDatabase.getInstance();
//
//                    time=txttime.getText()+"am";
//                    String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
//                    ownernotification_fragment Ofragment = new ownernotification_fragment();
//                    ref=database.getReference().child("renters").child(uid);
//                    ref.child("nf").child(str).child("Time").setValue(time);
//                    ref.child("nf").child(str).child("Date").setValue(date);
//                    ref.child("nf").child(str).child("Status").setValue("pending");
//                    ref.child("nf").child(str).child("ouid").setValue(str);
//
//                    Bundle args = new Bundle();
//                    args.putString("tuid", uid);
//                    args.putString("ouid", str);
//                    args.putString("date",date);
//                    args.putString("time",time);
//                    Ofragment.setArguments(args);
//                    FragmentManager manager = getSupportFragmentManager();
//                    FragmentTransaction t = manager.beginTransaction();
//                    t.add(R.id.Linearlayoutfinal, Ofragment);
//                    t.commit();
//                    request.setText("Requested!!!");
//
//                    Toast.makeText(getApplicationContext(), "msg sent", Toast.LENGTH_SHORT).show();
//                    //startActivity(intent);
//                }
//            });
            final ImageView fm=findViewById(R.id.motorimageowner);

            //loadMotorImage
            if(FirebaseAuth.getInstance().getCurrentUser()!=null)
            {
                Log.i("shubham","infirebaseauth");
                StorageReference iref = FirebaseStorage.getInstance().getReference().child("owners").child(str)
                        .child("motorimages").child("motorimage1");
                iref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        if(getApplicationContext()!=null)
                        {
                            Log.i("shubham","ingetapplicationcontext");
                            Picasso.with(getApplicationContext()).load(uri.toString()).into(fm);
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
            }

        }
    }

    public String getStrouid() {
        return strouid;
    }
}
