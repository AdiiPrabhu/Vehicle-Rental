package com.main.enroute.ownerclasses.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.main.enroute.R;
import com.main.enroute.ownerclasses.myVehicle.myVehicles;
import com.main.enroute.ownerclasses.postingNewVehicle.postNewVehicle1;

public class ownerdashboardfragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View root= inflater.inflate(R.layout.ownerdashboardfragment_layout, null);

        (root.findViewById(R.id.btnPostNewVehicle)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity().getApplicationContext(), postNewVehicle1.class));
            }
        });
        (root.findViewById(R.id.btnMyVehicles)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity().getApplicationContext(), myVehicles.class));
            }
        });
        return root;
    }
}
