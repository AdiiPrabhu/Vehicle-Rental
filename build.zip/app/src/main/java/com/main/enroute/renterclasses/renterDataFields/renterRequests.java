package com.main.enroute.renterclasses.renterDataFields;

public class renterRequests {
    String Date,Status,Time,ouid;

    public renterRequests(String date, String status, String time, String ouid) {
        Date = date;
        Status = status;
        Time = time;
        this.ouid = ouid;
    }

    public renterRequests() {
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getOuid() {
        return ouid;
    }

    public void setOuid(String ouid) {
        this.ouid = ouid;
    }
}
