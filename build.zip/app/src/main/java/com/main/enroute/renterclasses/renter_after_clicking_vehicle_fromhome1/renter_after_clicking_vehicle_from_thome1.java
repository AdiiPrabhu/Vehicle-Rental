package com.main.enroute.renterclasses.renter_after_clicking_vehicle_fromhome1;

import android.app.DatePickerDialog;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.ViewPager;

import com.main.enroute.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.main.enroute.ownerclasses.ownerDataFields.motorDetails;
import com.main.enroute.ownerclasses.ownerViewPageAdapter.ViewPagerAdapterOwner;
import com.main.enroute.renterclasses.renterViewPageAdapter.FragmentAddressRenter;
import com.main.enroute.renterclasses.renterViewPageAdapter.FragmentMotorRenter;
import com.main.enroute.renterclasses.renterViewPageAdapter.FragmentRentRenter;
import com.squareup.picasso.Picasso;

public class renter_after_clicking_vehicle_from_thome1 extends AppCompatActivity {
    DatabaseReference ref;
    private FirebaseAuth mAuth;
    FirebaseDatabase database;
    ImageView houseImage;
    String motoraddress1, motorno1;
    String bike1, bikeno1;
    String due1, city1;
    String area1, seater1, rent1, deposit1, document1, petrol1,  renter1, state1;
    String str,date,time;
    motorDetails fd;
    EditText eText,txttime;
    private TabLayout tablayout;
    private AppBarLayout appBarLayout;
    private ViewPager viewPager;
    String strouid;
    String key="";
    String imageUrl="";
    DatePickerDialog picker;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_renter_after_clicking_vehicle_from_thome1);

        tablayout = (TabLayout) findViewById(R.id.tablayout_id);
        appBarLayout = (AppBarLayout) findViewById(R.id.appbarid);
        viewPager = (ViewPager) findViewById(R.id.viewpager_id);
        // ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());

        //Adding Fragments

        //adapter Setup

        Bundle mBundle = getIntent().getExtras();

        if (mBundle != null) {

            str = mBundle.getString("Image");
            strouid = str;
            final ImageView fm=findViewById(R.id.motorimagerenter);

            if(FirebaseAuth.getInstance().getCurrentUser()!=null)
            {
                Log.i("shubham","infirebaseauth");
                Log.i("owneruid",strouid);
                StorageReference iref = FirebaseStorage.getInstance().getReference().child("owners").child(strouid)
                        .child("motorimages").child("motorimage1");
                iref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        if(getApplicationContext()!=null)
                        {
                            Log.i("shubham","ingetapplicationcontext");
                            Picasso.with(getApplicationContext()).load(uri.toString()).into(fm);
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });
            }

            FragmentManager manager = getSupportFragmentManager();
            final ViewPagerAdapterOwner adapter=new ViewPagerAdapterOwner(manager);
            adapter.AddFragment(new FragmentMotorRenter(), "Motor");
            adapter.AddFragment(new FragmentRentRenter(), "Rent");
            adapter.AddFragment(new FragmentAddressRenter(), "Address");

            viewPager.setAdapter(adapter);
            tablayout.setupWithViewPager(viewPager);
            houseImage = (ImageView) findViewById(R.id.motorimage);



        }
    }
    public String getStrouid() {
        return strouid;
    }

}
