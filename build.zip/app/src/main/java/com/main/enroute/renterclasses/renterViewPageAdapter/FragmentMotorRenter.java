package com.main.enroute.renterclasses.renterViewPageAdapter;

import android.app.DatePickerDialog;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.main.enroute.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.main.enroute.ownerclasses.ownerDataFields.motorDetails;
import com.main.enroute.renterclasses.renter_after_clicking_vehicle_fromhome1.renter_after_clicking_vehicle_from_thome1;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class FragmentMotorRenter extends Fragment {
    DatePickerDialog picker;
    private TimePicker timePicker1;
    static final int TIME_DIALOG_ID = 1111;
    DatabaseReference ref;
    String m,h;
    View view;
    String tuid,ouid;
    String motoraddress1, motorno1;
    String bike1, bikeno1;
    String due1, city1;
    String area1, seater1, rent1, deposit1, document1, petrol1, renter1, state1;
    String str;
    String date;
    String time;
    motorDetails fd;
    Button sendReq;
    EditText datehere;
    private Spinner spinner;
    private Calendar calendar;
    private String format = "";

    public FragmentMotorRenter() {
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_fragment_motor_renter,container,false);
        sendReq = (Button)view.findViewById(R.id.btnSendRequestToOwner);
        spinner = view.findViewById(R.id.spinner2);
        datehere = view.findViewById(R.id.date);
            tuid = FirebaseAuth.getInstance().getUid();
            ouid = ((renter_after_clicking_vehicle_from_thome1)getActivity()).getStrouid();

           final List<String>timings=new ArrayList<>();
            timings.add("Choose Time");
            timings.add("8am");
            timings.add("9am");
            timings.add("10am");
            timings.add("11am");
            timings.add("12pm");
            timings.add("1pm");
            timings.add("2pm");
            timings.add("3pm");
            timings.add("4pm");
            timings.add("5pm");
            timings.add("6pm");

            ArrayAdapter<String>dataAdapter=new ArrayAdapter(getContext(), R.layout.spinner_item,timings);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(dataAdapter);



            ref = FirebaseDatabase.getInstance().getReference().child("owners").child(ouid).child("fd");
            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if(dataSnapshot.child("document").getValue().toString().equals("true"))
                    {
                        document1="Document";
                    }
                    else
                    {
                        document1="Not Document";
                    }
                    seater1=dataSnapshot.child("seater").getValue(Long.class).toString();

                    if(dataSnapshot.child("due").getValue().toString().equals("true"))
                    {
                        due1="available";
                    }
                    else
                    {
                        due1="Not available";
                    }
                    renter1=dataSnapshot.child("renter").getValue(String.class);
                    ((TextView)view.findViewById(R.id.document)).setText(document1);
                    ((TextView)view.findViewById(R.id.seater)).setText(seater1);
                    ((TextView)view.findViewById(R.id.due)).setText(due1);
                    ((TextView)view.findViewById(R.id.renter)).setText(renter1);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        datehere.setInputType(InputType.TYPE_NULL);
        datehere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cldr = Calendar.getInstance();
                int day = cldr.get(Calendar.DAY_OF_MONTH);
                int month = cldr.get(Calendar.MONTH);
                int year = cldr.get(Calendar.YEAR);
                // date picker dialog
                picker = new DatePickerDialog(getContext(),
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                datehere.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                                date=(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);

                            }
                        }, year, month, day);
                picker.show();
            }
        });



        sendReq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                time=spinner.getSelectedItem().toString().trim();

                boolean flag=true;
                if(time.equals("Choose Time"))
                {
                    Toast.makeText(getContext(),"Choose Time",Toast.LENGTH_SHORT).show();
                    flag=false;
                    return;
                }
                if(date==null)
                {
                    Toast.makeText(getContext(),"Choose Date",Toast.LENGTH_SHORT).show();
                    flag=false;
                    return;
                }
                if(flag) {
                    ref = FirebaseDatabase.getInstance().getReference().child("renters").child(tuid);
                    ref.child("nf").child(ouid).child("Time").setValue(time);
                    ref.child("nf").child(ouid).child("Date").setValue(date);
                    ref.child("nf").child(ouid).child("Status").setValue("pending");
                    ref.child("nf").child(ouid).child("ouid").setValue(ouid);


                    ref = FirebaseDatabase.getInstance().getReference().child("owners").child(ouid);
                    ref.child("nf").child(tuid).child("Time").setValue(time);
                    ref.child("nf").child(tuid).child("Date").setValue(date);
                    ref.child("nf").child(tuid).child("Status").setValue("pending");
                    ref.child("nf").child(tuid).child("tuid").setValue(tuid);
                    Toast.makeText(getContext(), "msg sent", Toast.LENGTH_SHORT).show();
                    //startActivity(intent);
                }
            }
        });

        return view;
    }





}

