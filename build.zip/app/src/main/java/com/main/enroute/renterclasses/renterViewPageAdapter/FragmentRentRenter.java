package com.main.enroute.renterclasses.renterViewPageAdapter;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.main.enroute.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.main.enroute.ownerclasses.ownerDataFields.motorDetails;
import com.main.enroute.renterclasses.renter_after_clicking_vehicle_fromhome1.renter_after_clicking_vehicle_from_thome1;

public class FragmentRentRenter extends Fragment {
    DatabaseReference ref;
    String uid;
    String motoraddress1, motorno1;
    String bike1, bikeno1;
    String due1, city1;
    String area1, seater1,  document1,  renter1, state1;
    String str,rent1,deposit1,petrol1;
    motorDetails fd;
    SwipeRefreshLayout swipeRefresh;

    //EditText ren,dep,mai;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view=inflater.inflate(R.layout.activity_fragment_rent_renter, null);
        final TextView ren= ((TextView) view.findViewById(R.id.rent));
        final TextView dep= ((TextView) view.findViewById(R.id.deposit));
        final TextView mai= ((TextView) view.findViewById(R.id.petrol));
        ren.setText("ihdbeikfmenfuoiej");



        // Toast.makeText(getActivity().getApplicationContext(), uid, Toast.LENGTH_SHORT).show();

            uid = ((renter_after_clicking_vehicle_from_thome1)getActivity()).getStrouid();


        ref = FirebaseDatabase.getInstance().getReference().child("owners").child(uid).child("fd");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // fd = dataSnapshot.getValue(motorDetails.class);database = FirebaseDatabase.getInstance();
                //            ref = database.getReference().child("owners").child(ouid);
                //            ref.child("nf").child(tuid).child("Time").setValue(time);
                //            ref.child("nf").child(tuid).child("Date").setValue(date);
                //            ref.child("nf").child(tuid).child("Status").setValue("pending");
                //            ref.child("nf").child(tuid).child("tuid").setValue(tuid);
                // Toast.makeText(getActivity().getApplicationContext(), "Inside data snapshot", Toast.LENGTH_SHORT).show();
                rent1 = dataSnapshot.child("rent").getValue(Long.class).toString();
                deposit1 = dataSnapshot.child("deposit").getValue(Long.class).toString();
                petrol1 = dataSnapshot.child("petrol").getValue(Long.class).toString();
                ren.setText(rent1);
                dep.setText(deposit1);
                mai.setText(petrol1);

                //Toast.makeText(getActivity().getApplicationContext(), rent1, Toast.LENGTH_SHORT).show();
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {


            }
        });




        return view;
    }

}
