package com.main.enroute.renterclasses;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.main.enroute.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomnavigation.BottomNavigationView.OnNavigationItemSelectedListener;
import com.google.firebase.auth.FirebaseAuth;
import com.main.enroute.renterclasses.thome1.thome_1;
import com.main.enroute.renterclasses.tnotifications.renter_notification;
import com.main.enroute.renterclasses.tprofile1.renter_profile;


public class main_home_renter extends AppCompatActivity implements OnNavigationItemSelectedListener {
    String loggedas;
    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_home_renter);

        //getSupportActionBar().hide();

        loadFragment(new thome_1());

        //getting bottom navigation view and attaching the listener
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(this);
        Log.i("loggedas",getIntent().getExtras().getString("loggedas"));
        Log.i("loggedas1", FirebaseAuth.getInstance().getUid());
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Fragment fragment = null;

        switch (menuItem.getItemId()) {
            case R.id.navigation_home:
                fragment = new thome_1();
                break;

            case R.id.navigation_notifications:
                fragment = new renter_notification();
                break;

            case R.id.navigation_profile:
                fragment = new renter_profile();
                break;
        }
        return loadFragment(fragment);
    }

    public String getLoggedas(){
        return this.loggedas;
    }

}
