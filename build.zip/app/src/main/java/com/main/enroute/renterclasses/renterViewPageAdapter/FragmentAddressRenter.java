package com.main.enroute.renterclasses.renterViewPageAdapter;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.main.enroute.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.main.enroute.ownerclasses.ownerDataFields.motorDetails;
import com.main.enroute.renterclasses.renter_after_clicking_vehicle_fromhome1.renter_after_clicking_vehicle_from_thome1;

public class FragmentAddressRenter extends Fragment {
    DatabaseReference ref;
    View view;
    String uid;
    String motoraddress1, motorno1;
    String bike1, bikeno1;
    String due1, city1;
    String area1, seater1, rent1, deposit1,document1, petrol1, renter1, state1;
    String str,landmark;
    motorDetails fd;


    public FragmentAddressRenter() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_fragment_address_renter,container,false);

        {
            uid = ((renter_after_clicking_vehicle_from_thome1)getActivity()).getStrouid();
            ref = FirebaseDatabase.getInstance().getReference().child("owners").child(uid).child("fd");
            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    motoraddress1 = dataSnapshot.child("motoraddress").getValue(String.class);
                    fd = dataSnapshot.getValue(motorDetails.class);
                    motorno1 = dataSnapshot.child("motorno").getValue(Long.class).toString();
                    landmark = dataSnapshot.child("landmark").getValue(String.class);
                    bike1 = dataSnapshot.child("bikename").getValue(String.class);
                    bikeno1 = dataSnapshot.child("bikeno").getValue(Long.class).toString();
                    area1 = dataSnapshot.child("area").getValue(String.class);
                    city1 = dataSnapshot.child("city").getValue(String.class);

                    ((TextView) view.findViewById(R.id.bikeno)).setText(bikeno1);
                    ((TextView) view.findViewById(R.id.area)).setText(area1);
                    ((TextView) view.findViewById(R.id.motorno)).setText(motorno1);
                    ((TextView) view.findViewById(R.id.motoraddress)).setText(motoraddress1);
                    ((TextView) view.findViewById(R.id.bikename)).setText(bike1);
                    ((TextView) view.findViewById(R.id.city)).setText(city1);
                    ((TextView) view.findViewById(R.id.landmark)).setText(landmark);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
        return view;
    }

}
