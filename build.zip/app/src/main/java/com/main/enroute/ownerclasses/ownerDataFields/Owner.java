package com.main.enroute.ownerclasses.ownerDataFields;

public class Owner {
    people          pd;
    motorDetails     fd;

    public Owner() {
    }

    public Owner(people pd, motorDetails fd) {
        this.pd = pd;
        this.fd = fd;
    }

    public people getPd() {
        return pd;
    }

    public void setPd(people pd) {
        this.pd = pd;
    }

    public motorDetails getFd() {
        return fd;
    }

    public void setFd(motorDetails fd) {
        this.fd = fd;
    }
}
