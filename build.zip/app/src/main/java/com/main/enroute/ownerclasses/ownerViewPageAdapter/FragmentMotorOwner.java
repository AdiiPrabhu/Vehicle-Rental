package com.main.enroute.ownerclasses.ownerViewPageAdapter;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.main.enroute.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.main.enroute.ownerclasses.myVehicle.owner_after_clicking_hisvehicle;
import com.main.enroute.ownerclasses.ownerDataFields.motorDetails;

public class FragmentMotorOwner extends Fragment {
    DatabaseReference ref,ref1,ref2;
    String s1;
    Button deleteVehiclebyOwner;
    View view;
    String uid;
    String motoraddress1, motorno1;
    String bike1, bikeno1;
    String due1, city1;
    String area1, seater1, rent1, deposit1, document1, petrol1, renter1, state1;
    String str;
    motorDetails fd;
    public FragmentMotorOwner() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_fragment__motor__owner,container,false);
        {

            deleteVehiclebyOwner = view.findViewById(R.id.btnDeleteVehicle);
            uid = ((owner_after_clicking_hisvehicle)getActivity()).getStrouid();
            ref = FirebaseDatabase.getInstance().getReference().child("owners").child(uid).child("fd");
            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if(dataSnapshot.child("document").getValue().toString().equals("true"))
                    {
                        document1="Document";
                    }
                    else
                    {
                        document1="Not Document";
                    }
                    seater1=dataSnapshot.child("seater").getValue(Long.class).toString();

                    if(dataSnapshot.child("due").getValue().toString().equals("true"))
                    {
                        due1="available";
                    }
                    else
                    {
                        due1="Not available";
                    }
                    renter1=dataSnapshot.child("renter").getValue(String.class);
                     ((TextView)view.findViewById(R.id.document)).setText(document1);
                    ((TextView)view.findViewById(R.id.seater)).setText(seater1);
                    ((TextView)view.findViewById(R.id.due)).setText(due1);
                    ((TextView)view.findViewById(R.id.renter)).setText(renter1);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

            deleteVehiclebyOwner.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    final String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();

                   final FirebaseDatabase database = FirebaseDatabase.getInstance();
                    ref=database.getReference().child("owners").child(uid);
                    ref.child("fd").child("bikename").setValue("");
                    ref.child("fd").child("bikeno").setValue(-1);
                    ref.child("fd").child("area").setValue("");
                    ref.child("fd").child("seater").setValue(-1);
                    ref.child("fd").child("city").setValue("");
                    ref.child("fd").child("deposit").setValue(-1);
                    ref.child("fd").child("flag").setValue(false);
                    ref.child("fd").child("motorno").setValue(-1);
                    ref.child("fd").child("document").setValue(false);
                    ref.child("fd").child("landmark").setValue("");
                    ref.child("fd").child("due").setValue(false);
                    ref.child("fd").child("petrol").setValue(-1);
                    ref.child("fd").child("rent").setValue(-1);
                    ref.child("fd").child("state").setValue("");
                    ref.child("fd").child("renter").setValue("");

                    ref1=database.getReference().child("owners").child(uid).child("nf");
                    ref1.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            for(DataSnapshot p : dataSnapshot.getChildren())
                            {
                                p.child("Status").getRef().setValue("Delete");
                                s1=p.child("tuid").getValue().toString();
                                ref2 = database.getReference().child("renters").child(s1).child("nf").child(uid);
                                ref2.child("Status").getRef().setValue("Vehicle Deleted by Owner");
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                    //startActivity(new Intent(getApplicationContext(), ownerdashboardfragment.class));

                }
            });


        }
        return view;
    }

}