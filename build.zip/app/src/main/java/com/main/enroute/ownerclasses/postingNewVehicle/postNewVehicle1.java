package com.main.enroute.ownerclasses.postingNewVehicle;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.main.enroute.R;
import com.google.firebase.auth.FirebaseAuth;
import com.main.enroute.ownerclasses.ownerDataFields.motorDetails;

public class postNewVehicle1 extends AppCompatActivity {
CheckBox doc1,doc2,due1,due2;
Button btnContinue2;
EditText seater;

boolean flag1=true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_new_vehicle1);
        doc1=findViewById(R.id.docIdYes);
        doc2=findViewById(R.id.docIdNo);
        due1=findViewById(R.id.dueIdYes);
        due2=findViewById(R.id.dueIdNo);
        btnContinue2=findViewById(R.id.btnContinue2);

        seater=findViewById(R.id.txtseater);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        doc1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                {
                    doc2.setChecked(false);
                    ((TextView)findViewById(R.id.txtvdocument)).setError(null);
                }
            }
        });
        doc2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                {
                    doc1.setChecked(false);
                    ((TextView)findViewById(R.id.txtvdocument)).setError(null);
                }
            }
        });

        due1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                {
                    due2.setChecked(false);
                    ((TextView)findViewById(R.id.txtvdue)).setError(null);
                }
            }
        });
        due2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b){
                    due1.setChecked(false);
                    ((TextView)findViewById(R.id.txtvdue)).setError(null);
                }
            }
        });


        btnContinue2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag1=true;
                if(seater.getText().toString().trim().equalsIgnoreCase(""))
                {
                    seater.setError("Enter SEATER");
                    flag1=false;
                }
                if(!(doc1.isChecked()) && !(doc2.isChecked()))
                {
                    ((TextView)findViewById(R.id.txtvdocument)).requestFocus();
                    ((TextView)findViewById(R.id.txtvdocument)).setError("");
                    flag1=false;
                }
                if(!(due1.isChecked()) && !(due2.isChecked()))
                {
                    ((TextView)findViewById(R.id.txtvdue)).requestFocus();
                    ((TextView)findViewById(R.id.txtvdue)).setError("");
                    flag1=false;
                }



                if(flag1) {
                    int seater1=Integer.parseInt(seater.getText().toString().trim());
                    Boolean document=(doc1.isChecked())?true:false;
                    Boolean due=(due1.isChecked())?true:false;
                    String uid= FirebaseAuth.getInstance().getCurrentUser().getUid();
                    motorDetails fd=new motorDetails(seater1,document,due,uid);

                    Intent intent = new Intent(getApplicationContext(), postNewVehicle2.class);
                    intent.putExtra("motordetails1",fd);
                    startActivity(intent);
                }
            }
        });

    }
}
