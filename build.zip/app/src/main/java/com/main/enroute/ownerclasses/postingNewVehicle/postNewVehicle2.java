package com.main.enroute.ownerclasses.postingNewVehicle;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.main.enroute.R;
import com.main.enroute.ownerclasses.ownerDataFields.motorDetails;

public class postNewVehicle2 extends AppCompatActivity {

boolean flag1=false;
CheckBox bachelor,family,students;
EditText txtrent1,txtdeposit1,txtpetrol1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_new_vehicle2);

       final motorDetails fd=getIntent().getExtras().getParcelable("motordetails1");
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        bachelor=findViewById(R.id.bachelorsId);
        family=findViewById(R.id.familyId);
        students=findViewById(R.id.studentsId);

        txtrent1=findViewById(R.id.txtrent);
        txtdeposit1=findViewById(R.id.txtdeposit);
        txtpetrol1=findViewById(R.id.txtpetrol);


        bachelor.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                ((TextView)findViewById(R.id.txtvrenter)).setError(null);

            }
        });

        students.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                ((TextView)findViewById(R.id.txtvrenter)).setError(null);

            }
        });

        family.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                ((TextView)findViewById(R.id.txtvrenter)).setError(null);

            }
        });
        findViewById(R.id.btnContinue2).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                flag1=true;

                if(txtrent1.getText().toString().trim().equalsIgnoreCase(""))
                {
                    txtrent1.setError("Enter Rent Amount");
                    flag1=false;
                }
                if(txtdeposit1.getText().toString().trim().equalsIgnoreCase(""))
                {
                    txtdeposit1.setError("Enter Deposit Amount");
                    flag1=false;
                }
                if(txtpetrol1.getText().toString().trim().equalsIgnoreCase(""))
                {
                    txtpetrol1.setError("Enter Petrol Charge");
                    flag1=false;
                }

                if(!(bachelor.isChecked()) && !(family.isChecked()) && !(students.isChecked()))
                {
                    ((TextView)findViewById(R.id.txtvrenter)).requestFocus();
                    ((TextView)findViewById(R.id.txtvrenter)).setError(" ");
                    flag1=false;
                }

                if(flag1) {
                    String renter1="";
                    if(bachelor.isChecked())
                    {
                        renter1="Bachleors";
                    }
                    if(family.isChecked())
                    {
                        renter1=renter1+"/"+"Family";
                    }
                    if(students.isChecked())
                    {
                        renter1=renter1+"/"+"Students";
                    }
                    int rent1=Integer.parseInt(((EditText)findViewById(R.id.txtrent)).getText().toString());
                    int deposit1=Integer.parseInt(((EditText)findViewById(R.id.txtdeposit)).getText().toString());
                    int petrol1=Integer.parseInt(((EditText)findViewById(R.id.txtdeposit)).getText().toString());
                    fd.setRent(rent1);
                    fd.setDeposit(deposit1);
                    fd.setPetrol(petrol1);
                    fd.setRenter(renter1);

                    Intent intent = new Intent(getApplicationContext(), postNewVehicle3.class);
                    intent.putExtra("motordetails2",fd);
                    startActivity(intent);
                }
            }
        });
    }
}
