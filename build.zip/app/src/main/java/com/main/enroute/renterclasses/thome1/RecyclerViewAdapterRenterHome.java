package com.main.enroute.renterclasses.thome1;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.main.enroute.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.main.enroute.ownerclasses.ownerDataFields.motorDetails;
import com.main.enroute.renterclasses.renter_after_clicking_vehicle_fromhome1.renter_after_clicking_vehicle_from_thome1;
import com.squareup.picasso.Picasso;

import java.util.List;

public class RecyclerViewAdapterRenterHome extends RecyclerView.Adapter<RecyclerViewAdapterRenterHome.ViewHolder> {

    Context context;
    List<motorDetails> MainImageUploadInfoList;

    public RecyclerViewAdapterRenterHome(Context context, List<motorDetails> TempList) {

        this.MainImageUploadInfoList = TempList;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_items_renter_home_vehicles, parent, false);

        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {

        motorDetails fd = MainImageUploadInfoList.get(position);

        holder.tvuidhere.setText(fd.getUid());
        holder.tvareahere.setText("Area: "+fd.getArea());
        holder.tvrenthere.setText("Rs. "+fd.getRent()+"");
        holder.tvrentershere.setText("For: "+fd.getRenter());
        holder.tvseaterhere.setText("SEATER: "+fd.getSEATER()+"");
        holder.fdtemp=fd;

        if(FirebaseAuth.getInstance().getCurrentUser()!=null)
        {
            Log.i("shubham","infirebaseauth");
            Log.i("owneruid",fd.getUid());
            StorageReference iref = FirebaseStorage.getInstance().getReference().child("owners").child(fd.getUid())
                    .child("motorimages").child("motorimage1");
            iref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(Uri uri) {
                    if(context!=null)
                    {
                        Log.i("shubham","ingetapplicationcontext");
                        Picasso.with(context).load(uri.toString()).into(holder.motorimagehere);
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {

                }
            });
        }




        holder.mCardViewhere.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(context!=null) {
                    String str = ((TextView) view.findViewById(R.id.tvuid)).getText().toString();

                    Intent intent = new Intent(context, renter_after_clicking_vehicle_from_thome1.class);
                    intent.putExtra("Image", str);
                    intent.putExtra("Description", (R.drawable.background));

                    context.startActivity(intent);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return MainImageUploadInfoList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public motorDetails fdtemp;
        public TextView tvseaterhere;
        public TextView tvareahere;
        public TextView tvrentershere;
        public TextView tvrenthere;
        public ImageView motorimagehere;
        public TextView tvuidhere;
        public View mCardViewhere;
        Context contexttemp;

        public ViewHolder(View itemView) {

            super(itemView);
            itemView.setOnClickListener(this);

            contexttemp=itemView.getContext();
            motorimagehere = (ImageView) itemView.findViewById(R.id.motorimage);

            tvseaterhere = (TextView) itemView.findViewById(R.id.tvseater);

            tvareahere = (TextView) itemView.findViewById(R.id.tvarea);

            tvrentershere=(TextView)  itemView.findViewById(R.id.tvrenters);

            tvuidhere=(TextView)itemView.findViewById(R.id.tvuid);

            mCardViewhere = itemView.findViewById(R.id.myCardView);

            tvrenthere = (TextView) itemView.findViewById(R.id.tvrent);
        }

        @Override
        public void onClick(View view) {
//            String str=((TextView)view.findViewById(R.id.tvuid)).getText().toString();
//            Toast.makeText(view.getContext(),str+"   "+getLayoutPosition(),Toast.LENGTH_SHORT).show();

        }

        public motorDetails getFdtemp() {
            return fdtemp;
        }

        public void setFdtemp(motorDetails fdtemp) {
            this.fdtemp = fdtemp;
        }

        public TextView getTvseaterhere() {
            return tvseaterhere;
        }

        public void setTvseaterhere(TextView tvseaterhere) {
            this.tvseaterhere = tvseaterhere;
        }

        public TextView getTvareahere() {
            return tvareahere;
        }

        public void setTvareahere(TextView tvareahere) {
            this.tvareahere = tvareahere;
        }

        public TextView getTvrentershere() {
            return tvrentershere;
        }

        public void setTvrentershere(TextView tvrentershere) {
            this.tvrentershere = tvrentershere;
        }

        public TextView getTvrenthere() {
            return tvrenthere;
        }

        public void setTvrenthere(TextView tvrenthere) {
            this.tvrenthere = tvrenthere;
        }

        public ImageView getMotorimagehere() {
            return motorimagehere;
        }

        public void setMotorimagehere(ImageView motorimagehere) {
            this.motorimagehere = motorimagehere;
        }

        public Context getContexttemp() {
            return contexttemp;
        }

        public void setContexttemp(Context contexttemp) {
            this.contexttemp = contexttemp;
        }
    }
}