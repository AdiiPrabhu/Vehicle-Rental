package com.main.enroute.ownerclasses.ownerDataFields;

import android.os.Parcel;
import android.os.Parcelable;

public class motorDetails implements Parcelable {
 String motoraddress,bikename,city,state,renter,area,landmark,uid;
 int SEATER,deposit,motorno,rent,petrol,bikeno;
 boolean document,due,flag;

    public motorDetails(String uid) {
        this.motoraddress = "";
        this.bikename = "";
        this.city = "";
        this.state = "";
        this.renter = "";
        this.SEATER = -1;
        this.deposit = -1;
        this.motorno = -1;
        this.document = false;
        this.petrol = -1;
        this.rent = -1;
        this.due = false;
        this.area = "";
        this.landmark = "";
        this.bikeno = -1;
        this.flag = false;
        this.uid=uid;
    }

    public motorDetails(int SEATER, boolean document, boolean due,String uid) {
        this.SEATER = SEATER;
        this.document = document;
        this.due = due;
        this.uid=uid;
    }


    protected motorDetails(Parcel in) {
        motoraddress = in.readString();
        bikename = in.readString();
        city = in.readString();
        state = in.readString();
        renter = in.readString();
        area = in.readString();
        landmark = in.readString();
        SEATER = in.readInt();
        deposit = in.readInt();
        motorno = in.readInt();
        rent = in.readInt();
        petrol = in.readInt();
        bikeno = in.readInt();
        document = in.readByte() != 0;
       due = in.readByte() != 0;
        flag = in.readByte() != 0;
        uid = in.readString();
    }

    public static final Creator<motorDetails> CREATOR = new Creator<motorDetails>() {
        @Override
        public motorDetails createFromParcel(Parcel in) {
            return new motorDetails(in);
        }

        @Override
        public motorDetails[] newArray(int size) {
            return new motorDetails[size];
        }
    };

    public motorDetails() {
    }

    public String getMotoraddress() {
        return motoraddress;
    }

    public void setMotoraddress(String motoraddress) {
        this.motoraddress = motoraddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getRenter() {
        return renter;
    }

    public void setRenter(String renter) {
        this.renter = renter;
    }

    public int getSEATER() {
        return SEATER;
    }

    public void setSEATER(int SEATER) {
        this.SEATER = SEATER;
    }

    public int getDeposit() {
        return deposit;
    }

    public void setDeposit(int deposit) {
        this.deposit = deposit;
    }

    public int getMotorno() {
        return motorno;
    }

    public void setMotorno(int motorno) {
        this.motorno = motorno;
    }



    public int getPetrol() {
        return petrol;
    }

    public void setPetrol(int petrol) {
        this.petrol = petrol;
    }

    public int getRent() {
        return rent;
    }

    public void setRent(int rent) {
        this.rent = rent;
    }

    public String getBikename() {
        return bikename;
    }

    public void setBikename(String bikename) {
        this.bikename = bikename;
    }

    public boolean isDocument() {
        return document;
    }

    public void setDocument(boolean document) {
        this.document = document;
    }



    public boolean isDue() {
        return due;
    }

    public void setDue(boolean due) {
        this.due = due;
    }

    public int getBikeno() {
        return bikeno;
    }

    public void setBikeno(int bikeno) {
        this.bikeno = bikeno;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getLandmark() {
        return landmark;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(motoraddress);
        parcel.writeString(bikename);
        parcel.writeString(city);
        parcel.writeString(state);
        parcel.writeString(renter);
        parcel.writeString(area);
        parcel.writeString(landmark);
        parcel.writeInt(SEATER);
        parcel.writeInt(deposit);
        parcel.writeInt(motorno);
        parcel.writeInt(rent);
        parcel.writeInt(petrol);
        parcel.writeInt(bikeno);
        parcel.writeByte((byte) (document ? 1 : 0));
        parcel.writeByte((byte) (due ? 1 : 0));
        parcel.writeByte((byte) (flag ? 1 : 0));
        parcel.writeString(uid);
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
