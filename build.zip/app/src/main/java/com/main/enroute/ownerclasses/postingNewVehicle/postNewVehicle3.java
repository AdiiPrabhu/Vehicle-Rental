package com.main.enroute.ownerclasses.postingNewVehicle;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.main.enroute.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.main.enroute.ownerclasses.main_home_owner;
import com.main.enroute.ownerclasses.ownerDataFields.motorDetails;

import java.io.IOException;

public class postNewVehicle3 extends AppCompatActivity {
EditText motorno,bikename,bikeno,area,city,state,landmark;
Button btnContinue3;
ImageView uploadmotorimage;
TextView tvmotoriimagehere;
private FirebaseAuth mAuth;
private DatabaseReference ref;
private final int PICK_IMAGE_REQUEST = 71;
private Uri filePath;
String uid;
Boolean flag1;
ProgressDialog progressDialog;
FirebaseStorage storage;
StorageReference storageReference;
@Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_new_vehicle3);

        final motorDetails fdd=getIntent().getExtras().getParcelable("motordetails2");
        mAuth=FirebaseAuth.getInstance();
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

        motorno=findViewById(R.id.txtmotorno);
        bikename=findViewById(R.id.txtbikename);
        bikeno=findViewById(R.id.txtbikeno);
        area=findViewById(R.id.txtarea);
        city=findViewById(R.id.txtcity);
        state=findViewById(R.id.txtstate);
        landmark=findViewById(R.id.txtLandmark);
        btnContinue3=findViewById(R.id.btnContinue3);
        uploadmotorimage=findViewById(R.id.imageofmotor);
        tvmotoriimagehere = findViewById(R.id.tvmotorimage);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);


        btnContinue3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                flag1 = true;
                tvmotoriimagehere.setError(null);
                if (motorno.getText().toString().trim().equalsIgnoreCase("")) {
                    flag1 = false;
                    motorno.setError("Enter MotorNo");
                }

                if (bikename.getText().toString().trim().equalsIgnoreCase("")) {
                    flag1 = false;
                    bikename.setError("Enter Bike Name");
                }
                if (bikeno.getText().toString().trim().equalsIgnoreCase("")) {
                    flag1 = false;
                    bikeno.setError("Enter Bike Number");
                }
                if (area.getText().toString().trim().equalsIgnoreCase("")) {
                    flag1 = false;
                    area.setError("Enter Locality");
                }
                if (city.getText().toString().trim().equalsIgnoreCase("")) {
                    flag1 = false;
                    city.setError("Enter City");
                }
                if(state.getText().toString().trim().equalsIgnoreCase(""))
                {
                    flag1=false;
                    state.setError("Enter State");
                }
                if(landmark.getText().toString().trim().equalsIgnoreCase(""))
                {
                    flag1=false;
                    landmark.setError("Enter Landmark");
                }
                if(uploadmotorimage.getDrawable()==null)
                {
                    flag1=false;
                    tvmotoriimagehere.setError("Select Motor Images");
                }
                else
                {
                    tvmotoriimagehere.setError(null);
                }
                if (flag1) {

                    int motorno1 = Integer.parseInt(motorno.getText().toString());
                      String bikename1 = bikename.getText().toString();
                    int bikeno1 = Integer.parseInt(bikeno.getText().toString());
                    String area1 = area.getText().toString();
                    String city1 = city.getText().toString();
                    String state1 = state.getText().toString();
                    String landmark1 = landmark.getText().toString();

                    fdd.setMotorno(motorno1);
                    fdd.setBikename(bikename1);
                    fdd.setBikeno(bikeno1);
                    fdd.setArea(area1);
                    fdd.setCity(city1);
                    fdd.setState(state1);
                    fdd.setLandmark(landmark1);
                    fdd.setFlag(true);

                    //uploading motorimage in firestorage
                    uploadImageInFirestorage();


                    //uploading motor details in firebase realtime database
                    uploadInFirebase(fdd);

                    Intent i = new Intent(postNewVehicle3.this, main_home_owner.class);
                    i.putExtra("loggedas", "owners");
                    startActivity(i);

                    finish();
                }
            }
        });
        uploadmotorimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chooseImage();
            }
        });
    }

    public void uploadInFirebase(motorDetails fdd)
    {
        uid=mAuth.getCurrentUser().getUid();
        ref=FirebaseDatabase.getInstance().getReference().child("owners").child(uid);
        ref.child("fd").setValue(fdd);
        Toast.makeText(getApplicationContext(),"Posted",Toast.LENGTH_SHORT).show();
    }

    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null )
        {
            filePath = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                uploadmotorimage.setImageBitmap(bitmap);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }
    }
    private void uploadImageInFirestorage() {
    String uid1=mAuth.getCurrentUser().getUid();
        if(filePath != null)
        {
            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Uploading...");
            progressDialog.show();
            String pathofimage="owners"+"/"+uid1+"/"+"motorimages/";
            StorageReference ref = storageReference.child(pathofimage+ "motorimage1");

            ref.putFile(filePath)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                            Toast.makeText(getApplicationContext(), "Uploaded", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "Failed "+e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0*taskSnapshot.getBytesTransferred()/taskSnapshot
                                    .getTotalByteCount());
                            progressDialog.setMessage("Uploaded "+(int)progress+"%");
                        }
                    });
        }
        progressDialog.dismiss();
    }
}